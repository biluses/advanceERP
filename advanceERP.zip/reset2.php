<html>
 <head></head>
 <body>
  <?php
  require "config.php";
  $LS->forgotPassword();
  ?>
 </body>
</html>
