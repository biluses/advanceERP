<?php
require "config.php";
$LS->logout();
?>
