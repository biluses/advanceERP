# Simple-Notification-system-php
There are to files student1.php and student2.php 
the index.php has a simple form , and there are options to make announcement for diffrect class students. 
Here initially student1 and student 2 are two diffrenct classes as CSE101 and CSE102. 
You can make announcement for diffrent class and the notification will show to the student. 
ex: If you make announcement to student1 then it will show on student1.php. 
Thats it  Thanks.
for video : https://www.youtube.com/watch?v=ddki5_HVI10
